"""
Project 1: The To-Do List
--------------------------
DecodeLabs | Python Programming Industrial Training Kit | Batch 2026

Goal:
    Build a program where a user can add tasks (e.g. "Finish Python
    assignment") to a list and view them.

Key Skill:
    Lists (append & print loops)

Why it matters:
    This teaches how to store multiple items in a single variable -
    the foundation of every database you will ever build. Each task
    is modeled as a dictionary (id, task, status), and the collection
    of tasks is stored as a list of dictionaries - exactly like a
    single table in a real database.

Author: Mithin
"""

import json
import os

# ---------------------------------------------------------------------------
# STORAGE (Persistence layer)
# ---------------------------------------------------------------------------
# RAM (a plain Python list) is volatile - if the program closes, the data
# is lost. To make our to-do list "remember" tasks between runs, we
# serialize (JSON) the list to a file on disk and load it back on startup.

DATA_FILE = "tasks.json"


def load_tasks():
    """Load the task list from disk. Returns an empty list if no file exists."""
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            print("Warning: tasks.json was unreadable. Starting with an empty list.")
            return []
    return []


def save_tasks(tasks):
    """Save the current task list to disk as JSON."""
    with open(DATA_FILE, "w") as f:
        json.dump(tasks, f, indent=4)


# ---------------------------------------------------------------------------
# CORE LOGIC (Model layer)
# ---------------------------------------------------------------------------

def add_task(tasks, description):
    """
    Append a new task to the list.
    Each task is a dictionary -> {"id": int, "task": str, "done": bool}
    This mirrors a single row in a database table.
    """
    new_id = tasks[-1]["id"] + 1 if tasks else 1
    tasks.append({"id": new_id, "task": description, "done": False})
    print(f'Added task #{new_id}: "{description}"')


def view_tasks(tasks):
    """
    Print every task in the list using a for-loop.
    enumerate() gives us simultaneous access to the position (index)
    and the value (the task dictionary) - the "professional" way to
    loop instead of range(len(tasks)).
    """
    if not tasks:
        print("Your to-do list is empty. Add a task to get started!")
        return

    print("\n----- YOUR TO-DO LIST -----")
    for index, task in enumerate(tasks, start=1):
        status = "[X]" if task["done"] else "[ ]"
        print(f"{index}. {status} (ID {task['id']}) {task['task']}")
    print("----------------------------\n")


def complete_task(tasks, task_id):
    """Mark a task as done by its ID."""
    for task in tasks:
        if task["id"] == task_id:
            task["done"] = True
            print(f'Marked task #{task_id} as complete.')
            return
    print(f"No task found with ID {task_id}.")


def delete_task(tasks, task_id):
    """Remove a task from the list by its ID."""
    for task in tasks:
        if task["id"] == task_id:
            tasks.remove(task)
            print(f"Deleted task #{task_id}.")
            return
    print(f"No task found with ID {task_id}.")


# ---------------------------------------------------------------------------
# VIEW / INTERFACE layer (keeps user interaction separate from data logic)
# ---------------------------------------------------------------------------

def print_menu():
    print("""
========= DECODELABS TO-DO LIST =========
1. Add a task
2. View all tasks
3. Mark a task as complete
4. Delete a task
5. Exit
==========================================""")


def main():
    tasks = load_tasks()
    print("Welcome to your Python To-Do List!")

    while True:
        print_menu()
        choice = input("Choose an option (1-5): ").strip()

        if choice == "1":
            description = input("Enter the new task: ").strip()
            if description:
                add_task(tasks, description)
                save_tasks(tasks)
            else:
                print("Task description cannot be empty.")

        elif choice == "2":
            view_tasks(tasks)

        elif choice == "3":
            view_tasks(tasks)
            try:
                task_id = int(input("Enter the ID of the task to mark complete: "))
                complete_task(tasks, task_id)
                save_tasks(tasks)
            except ValueError:
                print("Please enter a valid numeric ID.")

        elif choice == "4":
            view_tasks(tasks)
            try:
                task_id = int(input("Enter the ID of the task to delete: "))
                delete_task(tasks, task_id)
                save_tasks(tasks)
            except ValueError:
                print("Please enter a valid numeric ID.")

        elif choice == "5":
            print("Goodbye! Your tasks have been saved to tasks.json.")
            break

        else:
            print("Invalid option. Please choose a number between 1 and 5.")


# Gatekeeper: only runs main() when this file is executed directly,
# not when it is imported as a module elsewhere.
if __name__ == "__main__":
    main()
